import time
from datetime import datetime
import tkinter as tk
import threading
from tkinter import simpledialog, messagebox

# --- Paramètres par défaut ---
message_text = "⛔ Temps d'écran terminé"
start_hour = 0   # Heure de début (0-23)
end_hour = 1     # Heure de fin (0-23)
fullscreen_window = None
active = True

# --- Fonction pour afficher le message ---
def show_message():
    global fullscreen_window
    fullscreen_window = tk.Toplevel()
    fullscreen_window.attributes('-fullscreen', True)
    fullscreen_window.configure(bg="black")
    tk.Label(fullscreen_window, text=message_text, fg="red", bg="black", font=("Segoe UI", 50)).pack(expand=True)
    fullscreen_window.update()

def close_message():
    global fullscreen_window
    if fullscreen_window:
        fullscreen_window.destroy()
        fullscreen_window = None

# --- Boucle horloge ---
def clock_loop():
    global active
    while True:
        if active:
            now = datetime.now()
            if now.hour == start_hour and fullscreen_window is None:
                show_message()
            elif now.hour == end_hour and fullscreen_window is not None:
                close_message()
        time.sleep(30)

# --- Menu simple pour personnaliser ---
def set_message():
    global message_text
    new_msg = simpledialog.askstring("Modifier message", "Entrez le nouveau message :")
    if new_msg:
        message_text = new_msg
        messagebox.showinfo("OK", "Message modifié !")

def set_hours():
    global start_hour, end_hour
    try:
        sh = int(simpledialog.askstring("Heure début", "Entrez l'heure de début (0-23) :"))
        eh = int(simpledialog.askstring("Heure fin", "Entrez l'heure de fin (0-23) :"))
        if 0 <= sh <= 23 and 0 <= eh <= 23:
            start_hour = sh
            end_hour = eh
            messagebox.showinfo("OK", f"Heures modifiées : {start_hour}:00 → {end_hour}:00")
        else:
            messagebox.showerror("Erreur", "Heure invalide !")
    except:
        messagebox.showerror("Erreur", "Entrée invalide !")

# --- Lancer la boucle horloge en arrière-plan ---
threading.Thread(target=clock_loop, daemon=True).start()

# --- Menu minimal pour modifier message et heures ---
root = tk.Tk()
root.title("Gestionnaire d'écran (arrière-plan)")
root.geometry("400x250")
root.configure(bg="#1e1e1e")

tk.Label(root, text="Gestionnaire d'écran", font=("Segoe UI", 18), bg="#1e1e1e", fg="white").pack(pady=20)

tk.Button(root, text="Modifier message", command=set_message, bg="#444", fg="white", font=("Segoe UI", 12), relief="flat").pack(pady=10, fill='x', padx=40)
tk.Button(root, text="Modifier heures", command=set_hours, bg="#444", fg="white", font=("Segoe UI", 12), relief="flat").pack(pady=10, fill='x', padx=40)
tk.Button(root, text="Quitter", command=lambda: root.destroy(), bg="#aa2222", fg="white", font=("Segoe UI", 12), relief="flat").pack(pady=10, fill='x', padx=40)

# --- Lancer l'interface --- 
root.mainloop()
